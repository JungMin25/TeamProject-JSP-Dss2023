package com.dss.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dss.dao.MemberDAO;
import com.dss.dto.MemberVO;

public class PwdFindCheckAction implements Action {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String url = "/member/pwdfind.jsp";

        MemberDAO memberDAO = MemberDAO.getInstance();
        MemberVO memberAllList = memberDAO.getMember(id);

        if (memberAllList != null) {
            // 아이디가 존재할 경우
            request.setAttribute("member", memberAllList);
        } else {
            // 아이디가 존재하지 않을 경우
            String errorMessage = "입력하신 아이디를 찾을 수 없습니다.";
            request.setAttribute("error", errorMessage);
        }

        RequestDispatcher rd = request.getRequestDispatcher(url);
        rd.forward(request, response);
    }
}